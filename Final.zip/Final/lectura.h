int leerentero(char*);
int leerEnteroPositivo(char*);
int leerenteroentre(char*, int, int);
int leerenteromayora(char*, int);
float leerflotante(char*);
float leerFlotantePositivo(char*);
float leerflotantentre(char*, float, float);
float leerflotantemayora(char*, float);
char leercaracter(char*);